/* const config = {
  user: "postgres",
  host: "localhost",
  password: "dannyalejo7123tapia",
  database: "thebronx",
}; */

const config = {
  user: "cpses_keaioww93y",
  host: "ec2-44-196-71-136.compute-1.amazonaws.com",
  password: "GYDkFq4qObRWwkc0XzcnnRfO7uv8Eaf7",
  database: "kengisof_thebronx",
  ssl: {
    rejectUnauthorized: false,
  },
};

module.exports = {
  config,
};
